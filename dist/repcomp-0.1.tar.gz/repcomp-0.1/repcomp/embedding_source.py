class EmbeddingSource(object):

  def __init__(self):
    pass

  def get_embedding(self, key):
    assert False

class W2VEmbeddingSource(object):

  def __init__(self, ):
    pass

  def get_embedding(self, key):
    assert False
