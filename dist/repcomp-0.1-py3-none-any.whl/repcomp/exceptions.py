class EmbeddingShapeMismatchException(Exception):
  pass


class MethodNotImplementedException(Exception):
  pass


class ImproperParameterSpecificationException(Exception):
  pass
